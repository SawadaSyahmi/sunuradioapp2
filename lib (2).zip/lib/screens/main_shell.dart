import 'dart:ui';

import 'package:flutter/material.dart';

import '../core/app_colors.dart';
import 'events_screen.dart';
import 'radio_screen.dart';
import 'settings_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 1;

  static const List<Widget> _screens = <Widget>[
    EventsScreen(),
    RadioScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Positioned.fill(child: _screens[_index]),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: _BottomDock(
              selectedIndex: _index,
              onChanged: (value) => setState(() => _index = value),
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomDock extends StatelessWidget {
  const _BottomDock({required this.selectedIndex, required this.onChanged});

  final int selectedIndex;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;
    final dockHeight = 64.0 + bottomInset;

    return SizedBox(
      width: double.infinity,
      height: dockHeight,
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: const Color(0xF205020A),
              border: Border(
                top: BorderSide(color: Colors.white.withOpacity(.14), width: 1),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.72),
                  blurRadius: 26,
                  offset: const Offset(0, -12),
                ),
              ],
            ),
            child: Padding(
              padding: EdgeInsets.fromLTRB(18, 8, 18, bottomInset + 7),
              child: Row(
                children: [
                  Expanded(
                    child: _NavItem(
                      icon: Icons.event_available_rounded,
                      label: 'Events',
                      selected: selectedIndex == 0,
                      onTap: () => onChanged(0),
                    ),
                  ),
                  Expanded(
                    child: _NavItem(
                      icon: Icons.podcasts_rounded,
                      label: 'Podcast',
                      selected: selectedIndex == 1,
                      onTap: () => onChanged(1),
                    ),
                  ),
                  Expanded(
                    child: _NavItem(
                      icon: Icons.settings_rounded,
                      label: 'Settings',
                      selected: selectedIndex == 2,
                      onTap: () => onChanged(2),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: label,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOutCubic,
            height: 49,
            margin: const EdgeInsets.symmetric(horizontal: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              gradient: selected ? AppColors.orangeGradient : null,
              color: selected ? null : Colors.white.withOpacity(.045),
              border: Border.all(
                color: selected ? Colors.white.withOpacity(.22) : Colors.white.withOpacity(.065),
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: AppColors.orange.withOpacity(.28),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ]
                  : null,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 18, color: selected ? Colors.white : AppColors.muted),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: selected ? Colors.white : AppColors.muted,
                      fontSize: 11.2,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -.15,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
