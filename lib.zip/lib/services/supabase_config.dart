class SupabaseConfig {
  const SupabaseConfig._();

  /// 1. Go to Supabase Dashboard > Project Settings > Data API.
  /// 2. Copy your Project URL and publishable/anon key here.
  ///
  /// Keep the service role key OUT of the Flutter app.
  static const String url = 'bvdrpfdmdsikeyzbqxpl.supabase.co/rest/v1/';
  static const String anonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ2ZHJwZmRtZHNpa2V5emJxeHBsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAzNzczNzAsImV4cCI6MjA5NTk1MzM3MH0.GYC5z93-amKXijXx9ovNJb0GAybrghDjtMLUbi5WXoA';

  static bool get isConfigured {
    return url.startsWith('https://') &&
        !url.contains('YOUR_SUPABASE') &&
        anonKey.isNotEmpty &&
        !anonKey.contains('YOUR_SUPABASE');
  }
}
